<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AplikasiController;

Route::get('/all', [AplikasiController::class,'All']);
Route::get('/relationship-1', [AplikasiController::class,'relationship1']);
Route::get('/relationship-2', [AplikasiController::class,'relationship2']);
Route::get('/relationship-3', [AplikasiController::class,'relationship3']);
Route::get('/count', [AplikasiController::class,'count']);
