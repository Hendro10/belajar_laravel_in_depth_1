<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mahasiswa extends Model
{
    use HasFactory;
    protected $guarded = [];

    protected $casts = [

        // 'ipk' => 'integer',
        'ipk' => 'decimal:1',
     ];

    // public function getNamaAttribute($value)
    // {
    //     return strtolower($value);
    //     return strtoupper($value);
    //     return $value." S.Kom";
    // }

    public function getNamaAttribute()
    {
        return "Sdr/i ".$this->attributes['nama'];
    }

    // public function getTanggalLahirAttribute($value)
    // {
    //     return date("d-m-Y", strtotime($value));
    // }

    public function getTanggalLahirAttribute($value)
    {
        $nama_bulan = ["Januari", "Februari", "Maret", "April", "Mei",
        "Juni", "Juli", "Agustus", "September", "Oktober",
        "November","Desember"];

        $tanggal = date("j", strtotime($value));
        $bulan = date("n", strtotime($value)) - 1;
        $tahun = date("Y", strtotime($value));

        return "$tanggal $nama_bulan[$bulan] $tahun";
    }

    public function getNamaBesarAttribute()
    {
        // return strtoupper($this->attributes['nama']);
        return strtoupper($this->nim);
    }

    public function setNamaAttribute($value)
    {
        $this->attributes['nama'] = strtolower($value);
    }
}
