<?php

use Illuminate\Support\Facades\Route;
use App\Models\Mahasiswa;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/generate', function () {
  Mahasiswa::create(
      [
          'nim' => '19003036',
          'nama' => 'Sari Citra Lestari',
          'tanggal_lahir' => '2001-12-31',
          'ipk' => 3.62,
      ]
      );
  Mahasiswa::create(
      [
          'nim' => '19021044',
          'nama' => 'Rudi Permana',
          'tanggal_lahir' => '2000-08-22',
          'ipk' => 2.99,
      ],
  );
  Mahasiswa::create(
      [
          'nim' => '19002032',
          'nama' => 'Rina Kumala Sari',
          'tanggal_lahir' => '2000-06-28',
          'ipk' => 3.82,
      ],
  );
  Mahasiswa::create(
      [
          'nim' => '18012012',
          'nama' => 'James Situmorang',
          'tanggal_lahir' => '1999-04-02',
          'ipk' => 2.74,
      ]
  );

  User::create(
      [
          'name' => 'Admin',
          'email' => 'admin@gmail.com',
          'password' => Hash::make('qwerty'),
      ]
  );

  return "Penambahan data tabel berhasil";
});


Route::get('/tampil1', function () {
    $mahasiswas = Mahasiswa::all();
    foreach ($mahasiswas as $mahasiswa) {
        echo "$mahasiswa->id | ";
        echo "$mahasiswa->nim | ";
        echo "$mahasiswa->nama | ";
        echo "$mahasiswa->tanggal_lahir | ";
        echo "$mahasiswa->ipk <hr>";
    }
});


Route::get('/tampil2', function () {
    $mahasiswas = Mahasiswa::all();
    foreach ($mahasiswas as $mahasiswa) {
        echo "$mahasiswa->id | ";
        echo "$mahasiswa->nim | ";
        echo strtolower($mahasiswa->nama)." | ";
        echo "$mahasiswa->tanggal_lahir | ";
        echo "$mahasiswa->ipk <hr>";
    }
});


Route::get('/tampil3', function () {
    $mahasiswas = Mahasiswa::all();
    foreach ($mahasiswas as $mahasiswa) {
        echo "$mahasiswa->id | ";
        echo "$mahasiswa->nim | ";
        echo "$mahasiswa->nama | ";
        echo "$mahasiswa->tanggal_lahir | ";
        echo "$mahasiswa->ipk | ";
        echo "$mahasiswa->nama_besar <hr>";
    }
});


Route::get('/tambah', function () {
    Mahasiswa::create(
        [
            'nim' => '19005011',
            'nama' => 'Riana Putria',
            'tanggal_lahir' => '2000-11-23',
            'ipk' => 2.9,
        ]
    );

    return "Berhasil di proses";
});


Route::get('/tambah-user1', function () {
    User::create(
        [
            'name' => 'Rudi',
            'email' => 'rudi@gmail.com',
            'password' => Hash::make('rahasia'),
        ]
    );

    return "Berhasil di proses";
});


Route::get('/tambah-user2', function () {
    User::create(
        [
            'name' => 'Alex',
            'email' => 'alex@gmail.com',
            'password' => 'qwerty',
        ]
    );

    return "Berhasil di proses";
});


Route::get('/tampil-user', function () {
  $users = User::all();
  foreach ($users as $user) {
      echo "$user->id | ";
      echo "$user->name | ";
      echo "$user->email | ";
      echo "$user->password <br><br>";
  }
});


Route::get('/tambah-user3', function () {
  User::create(
      [
          'name' => 'RIsSa',
          'email' => 'rissa@gmail.com',
          'password' => 'qwerty',
      ]
  );

  return "Berhasil di proses";
});