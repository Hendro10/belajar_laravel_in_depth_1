<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create('id_ID');
        $faker->seed(123);

        $daftar_titel = ["M.Kom", "M.Sc", "M.T", "M.Si"];
        for ($i=0; $i<5; $i++) {
          \App\Models\Dosen::create(
            [
                'nama' => $faker->firstName." ".$faker->lastName." ".
                          $faker->randomElement($daftar_titel)
            ]
          );
        }

        $jurusan = ["Ilmu Komputer", "Teknik Informatika", "Sistem Informasi"];
        for ($i=0; $i<5; $i++) {
          \App\Models\Mahasiswa::create(
            [
              'nama' => $faker->firstName." ".$faker->lastName,
              'jurusan' => $faker->randomElement($jurusan),
            ]
          );
        }

        $beasiswa = ["Pertamina", "Telkom", "LPDP", "Kemendikbud","PPA"];
        for ($i=0; $i<5; $i++) {
            \App\Models\Beasiswa::create(
              [
                'nama'=>"Beasiswa ".$faker->unique()->randomElement($beasiswa),
                'jumlah_dana' => $faker->numberBetween(5,12)*1000000,
              ]
            );
          }

    }
}
