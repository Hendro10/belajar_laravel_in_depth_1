<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AplikasiController;

Route::get('/all', [AplikasiController::class,'all']);

Route::get('/input-beasiswa-1', [AplikasiController::class,'inputBeasiswa1']);
Route::get('/input-beasiswa-2', [AplikasiController::class,'inputBeasiswa2']);

Route::get('/tampil-beasiswa-1',[AplikasiController::class,'tampilBeasiswa1']);
Route::get('/tampil-beasiswa-2',[AplikasiController::class,'tampilBeasiswa2']);
Route::get('/tampil-beasiswa-3',[AplikasiController::class,'tampilBeasiswa3']);
Route::get('/tampil-beasiswa-4',[AplikasiController::class,'tampilBeasiswa4']);

Route::get('/with-count',       [AplikasiController::class,'withCount']);

Route::get('/detach',           [AplikasiController::class,'detach']);

Route::get('/delete-beasiswa',  [AplikasiController::class,'deleteBeasiswa']);
Route::get('/delete-mahasiswa', [AplikasiController::class,'deleteMahasiswa']);
