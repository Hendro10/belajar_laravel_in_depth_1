<?php

use Illuminate\Support\Facades\Route;
use App\Models\Mahasiswa;
use App\Models\User;

// Test dump hasil factory, itu adalah sebuah model instance dari class mahasiswa
Route::get('/factory-mahasiswa', function () {
    $mahasiswa = Mahasiswa::factory()->make();
    dump ($mahasiswa);
});

// Tampilkan dengan echo, akses seperti data yang berasal dari eloquent
Route::get('/factory-mahasiswa-akses', function () {

  $mahasiswa = Mahasiswa::factory()->make();

  echo $mahasiswa->nim. '<br>';
  echo $mahasiswa->nama. '<br>';
  echo \Carbon\Carbon::parse($mahasiswa->tanggal_lahir)->isoFormat('D-M-YYYY');
  echo "<br>";
  echo $mahasiswa->ipk. '<br>';

});


// Buat 3 buah model instance mahasiswa / collection
Route::get('/factory-mahasiswa-array', function () {
    $mahasiswas = Mahasiswa::factory()->count(3)->make();

    foreach ($mahasiswas as $mahasiswa) {
        echo $mahasiswa->nim.  ' | ';
        echo $mahasiswa->nama. ' | ';
        $carbon_tgl_lahir = \Carbon\Carbon::parse($mahasiswa->tanggal_lahir);
        echo $carbon_tgl_lahir->isoFormat('D-M-YYYY'). " | ";
        echo $mahasiswa->ipk. '<hr>';
    }
});

// Penambahan array untuk menimpa nilai factory
Route::get('/factory-mahasiswa-tambah', function () {
    $mahasiswas = Mahasiswa::factory()->count(3)->make([
        'nama' => 'Rissa Permata',
        'jurusan' => 'Teknik Informatika',
    ]);
    foreach ($mahasiswas as $mahasiswa) {
        echo $mahasiswa->nim.  ' | ';
        echo $mahasiswa->nama. ' | ';
        $carbon_tgl_lahir = \Carbon\Carbon::parse($mahasiswa->tanggal_lahir);
        echo $carbon_tgl_lahir->isoFormat('D-M-YYYY'). " | ";
        echo $mahasiswa->ipk.  " | ";
        echo $mahasiswa->jurusan. '<hr>';
    }
});

// factory juga bisa langsung di input ke tabel, caranya pakai method create()
Route::get('/factory-mahasiswa-create', function () {
    Mahasiswa::factory()->create();
    return "Penambahan data berhasil";
});

Route::get('/factory-mahasiswa-create-10', function () {
    Mahasiswa::factory()->count(10)->create();
    return "Penambahan data berhasil";
});


// factory state

Route::get('/factory-user', function () {
  $user = User::factory()->make();
  dump($user);
});


Route::get('/factory-user-unverified', function () {
  $user = User::factory()->unverified()->make();
  dump($user);
});


Route::get('/mahasiswa-cumlaude', function () {
  $mahasiswa = Mahasiswa::factory()->cumlaude()->make();
  dump ($mahasiswa);
});


// generate 10 user dan 10 mahasiswa
Route::get('/factory-mahasiswa-user', function () {
    User::factory()->count(10)->create();
    Mahasiswa::factory()->count(10)->create();
    return "Penambahan data berhasil";
});
