<?php

namespace Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
// use Faker\Factory as Faker;

class MahasiswaFactory extends Factory
{
    public function definition()
    {
      return [
        'nim' => $this->faker->unique()->numerify('10######'),
        'nama' => $this->faker->firstName()." ".$this->faker->lastName(),
        'tanggal_lahir' => $this->faker->dateTimeInInterval('1999-01-01',
                           '+ 3 years'),
        'ipk' => $this->faker->randomFloat(2, 2, 4),
      ];
    }

    // ======================================================
    // Contoh untuk generate data factory dalam bahasa spanyol

    // $faker = Faker::create('es_ES');
    // return [
    //     'nim' => $faker->unique()->numerify('10######'),
    //     'nama' => $faker->firstName." ".$faker->lastName,
    //     'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01',
    //                        '+ 3 years'),
    //     'ipk' => $faker->randomFloat(2, 2, 4),
    // ];

    public function cumlaude()
    {
        return $this->state(function (array $attributes) {
            return [
               'ipk' => $this->faker->randomFloat(2, 3.5, 4),
            ];
        });
    }
}