<?php

use Illuminate\Support\Facades\Route;
use App\Models\Mahasiswa;

Route::get('/insert-mahasiswa-1', function () {
    $mahasiswa = new Mahasiswa;
    $mahasiswa->nim = '19003036';
    $mahasiswa->nama = 'Sari Citra Lestari';
    $mahasiswa->tanggal_lahir = '2001-12-31';
    $mahasiswa->ipk = 3.62;
    $mahasiswa->save();

    return "Penambahan mahasiswa berhasil";
});

Route::get('/insert-mahasiswa-2', function () {
    $mahasiswa = new Mahasiswa;
    $mahasiswa->nim = '19021044';
    $mahasiswa->nama = 'Rudi Permana';
    $mahasiswa->tanggal_lahir = '2000-08-22';
    $mahasiswa->ipk = 2.99;
    $mahasiswa->save();

    return "Penambahan mahasiswa berhasil";
});

Route::get('/insert-mahasiswa-3', function () {
    $mahasiswa = new Mahasiswa;
    $mahasiswa->nim = '19002035';
    $mahasiswa->save();

    return "Penambahan mahasiswa berhasil";
});


// Menampilkan data Eloquent dalam bentuk collection
Route::get('all', function () {
    $mahasiswas = Mahasiswa::all();

    // dump($mahasiswas);

    // dump($mahasiswas->toArray());

    // echo "<pre>";
    // print_r($mahasiswas->toArray());

    return view('mahasiswas',compact('mahasiswas'));
  });

// Menampilkan data Eloquent dalam bentuk 1 data model
Route::get('first', function () {
    $mahasiswa = Mahasiswa::first();
    // dump($mahasiswa);
    return view('mahasiswa',compact('mahasiswa'));
});


//====================
// ELOQUENT METHOD
//====================


//----------------
// all() dan get()
//----------------

Route::get('all', function () {
  $mahasiswas = Mahasiswa::all();
  return view('mahasiswas',compact('mahasiswas'));
});


Route::get('get', function () {
    $mahasiswas = Mahasiswa::get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('all-column', function () {
    $result = Mahasiswa::all(['nama','ipk']);
    dump($result->toArray());
});


Route::get('get-column', function () {
    $result = Mahasiswa::get(['nama','ipk']);
    dump($result->toArray());
});


//----------------
// select()
//----------------

Route::get('select', function () {
    $result = Mahasiswa::select('nama','ipk','nim')->get();
    dump($result->toArray());
});


//----------------
// orderby()
//----------------


Route::get('order-by-1', function () {
  $mahasiswas = Mahasiswa::orderBy('ipk')->get();
  return view('mahasiswas',compact('mahasiswas'));
});

Route::get('order-by-2', function () {
  $mahasiswas = Mahasiswa::orderBy('ipk','desc')->get();
  return view('mahasiswas',compact('mahasiswas'));
});

Route::get('order-by-desc', function () {
  $mahasiswas = Mahasiswa::orderByDesc('ipk')->get();
  return view('mahasiswas',compact('mahasiswas'));
});

Route::get('in-random-order', function () {
  $mahasiswas = Mahasiswa::inRandomOrder()->get();
  return view('mahasiswas',compact('mahasiswas'));
});



//----------------
// where()
//----------------


Route::get('where-1', function () {
  $mahasiswas = Mahasiswa::where('ipk',3)->get();
  return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-2', function () {
    $mahasiswas = Mahasiswa::where('ipk','>=',3)->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-3', function () {
    $mahasiswas = Mahasiswa::where('nama','LIKE','%i')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-order', function () {
  $mahasiswas = Mahasiswa::where('nama','LIKE','%i')
                ->orderBy('tanggal_lahir','desc')->get();
  return view('mahasiswas',compact('mahasiswas'));
});


Route::get('and-where-1', function () {
    $mahasiswas = Mahasiswa::where('nama','LIKE','%i')
                  ->where('ipk','>',2.7)->get();
    return view('mahasiswas',compact('mahasiswas'));
});

Route::get('and-where-2', function () {
    $mahasiswas = Mahasiswa::where([
                ['nama','LIKE','%i'],
                ['ipk','>',2.7]
                ])->get();
    return view('mahasiswas',compact('mahasiswas'));
});



//----------------
// orWhere()
//----------------


Route::get('or-where', function () {
    $mahasiswas = Mahasiswa::where('nama','LIKE','%i')
                  ->orWhere('ipk','>',2.7)->get();
    return view('mahasiswas',compact('mahasiswas'));
});



Route::get('where-chaining-1', function () {
  $mahasiswas = Mahasiswa::where('nama','LIKE','%i')
                ->orWhere('ipk','>',2.7)
                ->Where('ipk','<',3.0)
                ->get();
  return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-chaining-2', function () {
    $mahasiswas = Mahasiswa::where('nama','LIKE','%i')
                  ->orWhere(function($query) {
                       $query->where('ipk','>',2.7)->where('ipk','<',3.0);
                  }
                  )->get();
    return view('mahasiswas',compact('mahasiswas'));
});


//---------------------------------------
// whereBetween() dan whereNotBetween()
//---------------------------------------


Route::get('where-between', function () {
    $mahasiswas = Mahasiswa::whereBetween('ipk',[2.7,3.0])->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-not-between', function () {
    $mahasiswas = Mahasiswa::whereNotBetween('ipk',[2.7,3.0])->get();
    return view('mahasiswas',compact('mahasiswas'));
});



//----------------------------
// whereIn() dan whereNotIn()
//----------------------------


Route::get('where-in', function () {
    $mahasiswas = Mahasiswa::whereIn('ipk',[2.7,3.0])->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-not-in', function () {
    $mahasiswas = Mahasiswa::whereNotIn('id',[1,2,3,4,5])->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-in-chaining-1', function () {
  $mahasiswas = Mahasiswa::whereIn('ipk',[2.7,3.0])
                ->whereNotIn('id',[7,8,9])->get() ;
  return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-in-chaining-2', function () {
  $mahasiswas = Mahasiswa::whereIn('ipk',[2.7,3.0])
                ->orWhereNotIn('id',[7,8,9])->get() ;
  return view('mahasiswas',compact('mahasiswas'));
});


// ada juga orWhereIn() / orWhereNotIn()


//----------------------------
// whereNull() dan whereNotNull()
//----------------------------



Route::get('where-null', function () {
    $mahasiswas = Mahasiswa::whereNull('tanggal_lahir')->get();
    return view('mahasiswas',compact('mahasiswas'));
});

Route::get('where-not-null', function () {
    $mahasiswas = Mahasiswa::whereNotNull('tanggal_lahir')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


// ada juga orWhereNull() / orWhereNotNull()



//---------------------------------------------------------------------
// whereDate() / whereMonth() / whereDay() / whereYear() / whereTime()
//---------------------------------------------------------------------


Route::get('where-date', function () {
    $mahasiswas = Mahasiswa::whereDate('tanggal_lahir','2000-09-23')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-month', function () {
    $mahasiswas = Mahasiswa::whereMonth('tanggal_lahir','12')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-day', function () {
    $mahasiswas = Mahasiswa::whereDay('tanggal_lahir','>','20')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-year', function () {
    $mahasiswas = Mahasiswa::whereYear('tanggal_lahir','2000')->get();
    return view('mahasiswas',compact('mahasiswas'));
});


Route::get('where-time', function () {
    $mahasiswas = Mahasiswa::whereTime('created_at','>','20:00:00')->get();
    return view('mahasiswas',compact('mahasiswas'));
});



//------------
// limit()
//----------


Route::get('limit', function () {
    $mahasiswas = Mahasiswa::orderBy('ipk','desc')->limit(3)->get();
    return view('mahasiswas',compact('mahasiswas'));
});



//------------
// skip() dan take()
//----------


Route::get('skip-take', function () {
    $mahasiswas = Mahasiswa::orderBy('ipk','desc')->skip(2)->take(3)->get();
    return view('mahasiswas',compact('mahasiswas'));
});



//------------
// first() dan firstWhere()
//----------


Route::get('first', function () {
  $mahasiswa = Mahasiswa::first();
  return view('mahasiswa',compact('mahasiswa'));
});

Route::get('order-by-first', function () {
  $mahasiswa = Mahasiswa::orderBy('ipk','desc')->first();
  return view('mahasiswa',compact('mahasiswa'));
});

Route::get('where-first', function () {
  $mahasiswa = Mahasiswa::where('ipk','<=',3)->first();
  return view('mahasiswa',compact('mahasiswa'));
});

Route::get('first-where', function () {
  $mahasiswa = Mahasiswa::firstWhere('ipk','<=',3);
  return view('mahasiswa',compact('mahasiswa'));
});



//------------
// latest()
//----------


Route::get('latest', function () {
    $mahasiswas = Mahasiswa::latest()->get();
    // sama dengan $mahasiswas = Mahasiswa::orderBy('created_at','desc')->get();
    return view('mahasiswas',compact('mahasiswas'));
});

Route::get('latest-first', function () {
  $mahasiswa = Mahasiswa::latest()->first();
  return view('mahasiswa',compact('mahasiswa'));
});



//------------------------
// find() dan findOrFail()
//-----------------------


Route::get('find', function () {
  $mahasiswa = Mahasiswa::find(5);
  return view('mahasiswa',compact('mahasiswa'));
});

Route::get('find-array', function () {
  $mahasiswas = Mahasiswa::find([1,4,6,7]);
  return view('mahasiswas',compact('mahasiswas'));
});

Route::get('find-error', function () {
  $mahasiswas = Mahasiswa::find(99);
  return view('mahasiswas',compact('mahasiswas'));
});

Route::get('find-or-fail', function () {
  $mahasiswas = Mahasiswa::findOrFail(99);
  return view('mahasiswas',compact('mahasiswas'));
});


//---------
// value()
//---------


Route::get('value-1', function () {
    $result = Mahasiswa::value('nama');
    echo $result;   // Mustofa Simanjuntak
});

Route::get('value-2', function () {
    $result = Mahasiswa::where('nama','Clara Wijaya')->value('ipk');
    echo $result;   // 3.00
});


//---------
// pluck()
//---------


Route::get('pluck', function () {
    $result = Mahasiswa::pluck('nama');
    dump($result);
});

Route::get('where-pluck', function () {
    $result = Mahasiswa::where('nama','LIKE','%i')->pluck('ipk');
    dump($result);
});


//-----------------------------
// exists() dan doesntExist()
//-----------------------------


Route::get('exists', function () {
  $result = Mahasiswa::where('ipk','>',3.6)->exists();
  dump($result);  // false

  $result = Mahasiswa::where('nama','LIKE','%a')->exists();
  dump($result);  // true
});


Route::get('doesnt-exist', function () {
  $result = Mahasiswa::where('ipk','>',3.6)->doesntExist();
  dump($result);  // true

  $result = Mahasiswa::where('nama','LIKE','%a')->doesntExist();
  dump($result);  // false
});


// Aggregate method
//---------------------------------
// count(), max(), min() dan avg()
//---------------------------------

Route::get('aggregate', function () {
    $result = Mahasiswa::all()->count();
    dump($result);  // 10

    $result = Mahasiswa::where('nama','LIKE','%e%')->count();
    dump($result);  // 5

    $result = Mahasiswa::all()->max('ipk');
    dump($result);  // 3.16

    $result = Mahasiswa::where('nama','LIKE','%e%')->max('tanggal_lahir');
    dump($result);  // 2001-06-10

    $result = Mahasiswa::all()->min('ipk');
    dump($result);  // 2.15

    $result = Mahasiswa::all()->avg('ipk');
    dump($result);  // 2.679
});



//------------------
// firstOrCreate()
//------------------


Route::get('first-or-create', function () {
    $mahasiswa = Mahasiswa::firstOrCreate(['nama' => 'Shania Pertiwi']);

    // bisa error jika tidak ditemukan, karena tidak ada nilai yang mengenerate kolom nim
    $mahasiswa = Mahasiswa::firstOrCreate(['nama' => 'Nova Pertiwi']);
    return view('mahasiswa',compact('mahasiswa'));
});

Route::get('first-or-create-input', function () {
  $mahasiswa = Mahasiswa::firstOrCreate(
      ['nama' => 'Nova Pertiwi'],
      [
          'nim' => '10512007',
          'ipk' => 3.4,
      ]
  );
  return view('mahasiswa',compact('mahasiswa'));
});


Route::get('first-or-create-faker', function () {
    $mahasiswa = Mahasiswa::firstOrCreate(
        ['nama' => 'Nova Pertiwi'],
        [
            'nim' => Faker\Factory::create()->unique()->numerify('10######'),
            'ipk' => Faker\Factory::create()->randomFloat(2, 2, 4),
        ]
    );
    return view('mahasiswa',compact('mahasiswa'));
});



//------------------
// firstOrNew()
//------------------


Route::get('first-or-new', function () {
  $faker = \Faker\Factory::create('id_ID');
  $mahasiswa = Mahasiswa::firstOrNew(
    ['nama' => 'Lisa Pertiwi'],
    [
      'id'  => $faker->numberBetween(100,199),
      'nim' => $faker->numerify('10######'),
      'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01', '+3 years'),
      'ipk' => $faker->randomFloat(2, 2, 4),
      'created_at' => $faker->dateTimeBetween('-10 days', '-5 days'),
      'updated_at' => $faker->dateTimeBetween('-3 days'),
    ]
  );
  return view('mahasiswa',compact('mahasiswa'));
});


Route::get('first-or-new-save', function () {
  $faker = \Faker\Factory::create('id_ID');
  $mahasiswa = Mahasiswa::firstOrNew(
    ['nama' => 'Lisa Pertiwi'],
    [
      'id'  => $faker->numberBetween(100,199),
      'nim' => $faker->numerify('10######'),
      'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01', '+3 years'),
      'ipk' => $faker->randomFloat(2, 2, 4),
      'created_at' => $faker->dateTimeBetween('-10 days', '-5 days'),
      'updated_at' => $faker->dateTimeBetween('-3 days'),
    ]
  );
  // save data mahasiswa ke database
  $mahasiswa->save;
  return view('mahasiswa',compact('mahasiswa'));
});


//--------------
// firstOr()
//--------------


Route::get('first-or', function () {
    $faker = \Faker\Factory::create('id_ID');
    $mahasiswa = Mahasiswa::where('nama','Dewi Pertiwi')->firstOr(
        function () {
          return Mahasiswa::find(5);
          // jika ada factory, bisa dipanggil disini
          //  return Mahasiswa::factory()->make();
        }
    );

    return view('mahasiswa',compact('mahasiswa'));
  });


//------------------
// updateOrCreate()
//------------------

Route::get('update-or-create', function () {
    $mahasiswa = Mahasiswa::updateOrCreate(
        ['nama' => 'Naira Pertiwi'],
        [
            'nim' => Faker\Factory::create()->unique()->numerify('10######'),
            'ipk' => 3.99,
        ]
    );
    return view('mahasiswa',compact('mahasiswa'));
});
