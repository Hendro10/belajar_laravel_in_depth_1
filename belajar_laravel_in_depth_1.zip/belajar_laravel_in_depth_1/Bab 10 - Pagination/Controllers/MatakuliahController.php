<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MatakuliahController extends Controller
{
    public function index()
    {
        // $matakuliahs = \App\Models\Matakuliah::all();
        // $matakuliahs = \App\Models\Matakuliah::paginate(10);
        // $matakuliahs = \App\Models\Matakuliah::where('jumlah_sks', 4)->paginate(5);
        // $matakuliahs = \App\Models\Matakuliah::where('jumlah_sks', 4)
        //                ->orderBy('nama_matakuliah')
        //                ->paginate(5);

        // $matakuliahs = \App\Models\Matakuliah::simplePaginate(10);

        $matakuliahs = \App\Models\Matakuliah::paginate(5);
        return view('index',['matakuliahs' => $matakuliahs]);
    }

    // Untuk melihat isi $paginator object
    public function testPaginate()
    {
        $matakuliahs = \App\Models\Matakuliah::paginate(5);
        return view('test',['matakuliahs' => $matakuliahs]);
    }
}
