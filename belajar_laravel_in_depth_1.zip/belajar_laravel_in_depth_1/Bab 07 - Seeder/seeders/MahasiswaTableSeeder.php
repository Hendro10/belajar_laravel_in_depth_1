<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Mahasiswa;
use Faker\Factory as Faker;

class MahasiswaTableSeeder extends Seeder
{
    public function run()
    {
      $faker = Faker::create('id_ID');

      for ($i=0; $i<10; $i++) {
          Mahasiswa::create(
              [
                  'nim' => $faker->numerify('10######'),
                  'nama' => $faker->firstName()." ".$faker->lastName(),
                  'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01',
                                  '+ 3 years'),
                  'ipk' => $faker->randomFloat(2, 2, 4),
              ]
          );
      }
    }
}
