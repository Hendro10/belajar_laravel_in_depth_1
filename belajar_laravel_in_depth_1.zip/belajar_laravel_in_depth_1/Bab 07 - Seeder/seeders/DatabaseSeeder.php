<?php

namespace Database\Seeders;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
      // ==================
      // GENERATE MANUAL
      // ==================

      Mahasiswa::create(
        [
            'nim' => '19003036',
            'nama' => 'Sari Citra Lestari',
            'tanggal_lahir' => '2001-12-31',
            'ipk' => 3.62,
        ]
      );

      // Mahasiswa::create(
      //     [
      //         'nim' => '19021044',
      //         'nama' => 'Rudi Permana',
      //         'tanggal_lahir' => '2000-08-22',
      //         'ipk' => 2.99,
      //     ],
      // );
      // Mahasiswa::create(
      //     [
      //         'nim' => '19002032',
      //         'nama' => 'Rina Kumala Sari',
      //         'tanggal_lahir' => '2000-06-28',
      //         'ipk' => 3.82,
      //     ],
      // );
      // Mahasiswa::create(
      //     [
      //         'nim' => '18012012',
      //         'nama' => 'James Situmorang',
      //         'tanggal_lahir' => '1999-04-02',
      //         'ipk' => 2.74,
      //     ]
      // );

      // User::create(
      //     [
      //         'name' => 'Admin',
      //         'email' => 'admin@gmail.com',
      //         'password' => Hash::make('qwerty'),
      //     ]
      // );






      // ==================
      // GENERATE + FAKER
      // ==================

      // $faker = Faker::create('id_ID');

      // Mahasiswa::create(
      //     [
      //         'nim' => $faker->numerify('10######'),
      //         'nama' => $faker->firstName()." ".$faker->lastName(),
      //         'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01',
      //                            '+ 3 years'),
      //         'ipk' => $faker->randomFloat(2, 2, 4),
      //     ]
      // );

      // User::create(
      //     [
      //         'name' => $faker->firstName(),
      //         'email' => $faker->unique()->email,
      //         'password' => Hash::make('qwerty'),
      //     ]
      // );







      // ==================
      // GENERATE + FAKER + FOR LOOP
      // ==================

      // $faker = Faker::create('id_ID');

      // for ($i=0; $i<100; $i++) {

      //     Mahasiswa::create(
      //         [
      //             'nim' => $faker->numerify('10######'),
      //             'nama' => $faker->firstName()." ".$faker->lastName(),
      //             'tanggal_lahir' => $faker->dateTimeInInterval('1999-01-01',
      //                             '+ 3 years'),
      //             'ipk' => $faker->randomFloat(2, 2, 4),
      //         ]
      //     );

      //     User::create(
      //         [
      //             'name' => $faker->firstName(),
      //             'email' => $faker->unique()->email(),
      //             'password' => Hash::make('qwerty'),
      //         ]
      //     );
      // }


      // ==================
      // JALANKAN FILE SEEDER TERPISAH
      // ==================

      // $this->call(MahasiswaTableSeeder::class);
      // $this->call(UserTableSeeder::class);
    }
}