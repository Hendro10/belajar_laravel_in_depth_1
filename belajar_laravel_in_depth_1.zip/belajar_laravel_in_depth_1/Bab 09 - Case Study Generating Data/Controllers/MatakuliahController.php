<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MatakuliahController extends Controller
{
    public function index()
    {
        $matakuliahs = \App\Models\Matakuliah::all();
        return view('index',['matakuliahs' => $matakuliahs]);
    }
}
