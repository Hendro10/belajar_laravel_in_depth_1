<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MatakuliahSeeder extends Seeder
{
    public function run()
    {
      \App\Models\Matakuliah::factory()->count(100)->create();
    }
}
