<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AplikasiController;

Route::get('/input-beasiswa-1', [AplikasiController::class,'inputBeasiswa1']);
Route::get('/input-beasiswa-2', [AplikasiController::class,'inputBeasiswa2']);

Route::get('/tampil-beasiswa-1',[AplikasiController::class,'tampilBeasiswa1']);
Route::get('/tampil-beasiswa-2',[AplikasiController::class,'tampilBeasiswa2']);
Route::get('/tampil-beasiswa-3',[AplikasiController::class,'tampilBeasiswa3']);

Route::get('/wherehasmorph',    [AplikasiController::class,'wherehasmorph']);

Route::get('/update-beasiswa',  [AplikasiController::class,'updateBeasiswa']);

Route::get('/delete',           [AplikasiController::class,'delete']);
