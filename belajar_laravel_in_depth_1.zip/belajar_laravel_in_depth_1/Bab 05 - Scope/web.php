<?php

use Illuminate\Support\Facades\Route;
use App\Models\Mahasiswa;


// Tampilkan semua mahasiswa dengan ipk > 3.5
Route::get('/mahasiswa-ipk', function () {
    $mahasiswas = Mahasiswa::where('ipk','>','3.5')->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});


// Tampilkan semua mahasiswa dengan ipk > 3.5 dengan scope
Route::get('/mahasiswa-ipk-scope', function () {
    $mahasiswas = Mahasiswa::cumlaude()->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});


// Tampilkan semua mahasiswa yang lahir di tahun 2000
Route::get('/mahasiswa-lahir', function () {
    $mahasiswas = Mahasiswa::whereYear('tanggal_lahir','=','2000')->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});


// Tampilkan semua mahasiswa yang lahir di tahun 2000 dengan scope
Route::get('/mahasiswa-lahir-scope', function () {
    $mahasiswas = Mahasiswa::lahir2000()->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});


// Tampilkan semua mahasiswa yang lahir di tahun yang bisa diisi secara dinamis (Dynamic Scopes)
Route::get('/tampil-lahir-scope-dynamic', function () {
    $mahasiswas = Mahasiswa::lahir(2001)->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});

// Tampilkan semua mahasiswa yang lahir di tahun 2000 dan cumlaude
Route::get('/scope-chain', function () {
    $mahasiswas = Mahasiswa::lahir(2000)->cumlaude()->get();
    foreach ($mahasiswas as $mahasiswa) {
        echo($mahasiswa->nama). '<br>';
    }
});
